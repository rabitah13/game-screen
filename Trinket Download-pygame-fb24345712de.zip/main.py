import pygame

pygame.init()

screen = pygame.display.set_mode((800, 600))


white = (255, 255, 255)
blue = (0, 0, 255)
black = (0, 0, 0)

font = pygame.font.sysfont("Arial", 36)

text = font.render("WELCOME TO MY FIRST GAME", True,black)

running = True
while running:
    screen.fill(white)
    
    pygame.draw.rect(screen, blue, (300, 250, 200, 100))
    
    screen.blit(text, (220, 150))
    
    for event in pygame .event.get():
      if event.type == pygame.QUIT:
        running = False
    pygame.display.update()
pygame.quit()    
    
    
    
        
      
    
    